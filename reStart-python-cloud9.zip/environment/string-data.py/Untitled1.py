myString = "This is a string."
print(myString)
print(type(myString))
print(myString + " is of the data type " + str(type(myString)))
firstString = "water"
secondString = "fall"
thirdString = firstString + secondString
print(thirdString)
name = input("What is your name? mouni")
print()
color = input("What is your favorite color? orange ")
print(color)
animal = input("What is your favorite animal? tiger")
print("{}, you like a {} {}!".format(mouni,corange,tiger))




