# 1 Create a list Missing module docstring
myFruitList = ["apple", "banana", "cherry"]

# 2 Print the list and its type
print(myFruitList)
print(type(myFruitList))

# 3 Access items in the list by position
print(myFruitList[0]) # Print "apple"
print(myFruitList[1]) # Print "banana"
print(myFruitList[2]) # Print "cherry"
myFruitList[2] = "orange"
print(myFruitList) # Print "orange"
myFinalAnswerTuple = ("apple", "banana", "pineapple")
print(myFinalAnswerTuple)
print(type(myFinalAnswerTuple))
print(myFinalAnswerTuple[0]) # Print "apple"
print(myFinalAnswerTuple[1]) # Print "banana"
print(myFinalAnswerTuple[2]) # Print "pineapple"
myFavoriteFruitDictionary = {
  "Akua" : "apple",
  "Saanvi" : "banana",
  "Paulo" : "pineapple"
}
print(myFavoriteFruitDictionary)
print(type(myFavoriteFruitDictionary))
print(myFavoriteFruitDictionary["Akua"])
print(myFavoriteFruitDictionary["Saanvi"])
print(myFavoriteFruitDictionary["Paulo"])











